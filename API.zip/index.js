var express = require('express');
var app = express();



var mysql = require('mysql');
var cors = require('cors');

app.use(cors());

var connection = mysql.createConnection({
    host: 'localhost',
    user: 'dafneore',
    password: '123',
    database: 'restaurant'
});

/*SELECT  product_name,price,created_date,modified_date 
FROM    menu; */


//crear api probar el flujo que se quiere hacer

app.get('/menu',getMenu);

function getMenu(req,res){
    // Step 0: Setup the connection
    var connection = mysql.createConnection({
        host: 'localhost',
        user: 'utec',
        password: '1234567890',
        database: 'restaurant'
    });
  
    // Step 1: Open the connection
    connection.connect();
  
    // Step 2: Send the query
    const myQuery = " SELECT  product_name,price, " +
                    " created_date,modified_date" +
                    " FROM menu; ";
  
    connection.query(myQuery, function (error, results, fields) {
      
      // Step 3: Process the result inside the callback
      //El resultado del Query en results
      res.send(results);
  
      // Step 4: Close the connection
      connection.end();
    });
  
  }
  

app.listen(3000, function(){
    console.log("Server started in port 3000")
})



// ¡¡¡ PEGAR ESTO EN POSTMAAAAN !!!!!

// 127.0.0.1:3000/menu